from django.shortcuts import render,get_object_or_404, redirect
from django.http import HttpResponse
from django.views import View
from .models import Category, Note
from .forms import NoteForm, CategoryForm
from django.contrib.auth.decorators import login_required

#def index(request):
#    return HttpResponse("Hello from Notes app.")

# Create your views here.
#def index(request):
#    return render(request, "notes1/index.html") # request, hello/greet.html


#def home(request):
#    notes = ['Note1', 'Note2', 'Note3', 'Note4', 'Note5'] # our test data
#    return render (request, 'notes1/home.html', {'notes':notes})

#def home(request):
#    notes = [
#        {'title': 'Note1', 'content': 'This is the first note.'},
#        {'title': 'Note2', 'content': 'This is the second note.'},
#        {'title': 'Note3', 'content': 'This is the third note.'},
#        {'title': 'Note4', 'content': 'This is the third note.'},
#        {'title': 'Note5', 'content': 'This is the third note.'},
#
#    ]  # Тестові дані

#    return render(request, 'notes1/home.html', {'notes': notes})

def home(request): #good
    notes = Note.objects.all()
    return render(request, 'notes1/home.html', {'notes':notes})


@login_required
def creator_view(request):
    user = request.user
    notes = Note.objects.filter(creator=user)
    context = {'notes':notes}
    return render(request, 'notes1/creator_view.html', context)

@login_required
def note_create(request, category_id):
    category = get_object_or_404(Category, id=category_id)

    if request.method == 'POST':
        form = NoteForm(request.POST)
        if form.is_valid():
            note = form.save(commit=False)
            note.category = category
            note.save()
            return redirect('notes1:category_detail', category_id=category.id)
    else:
        form = NoteForm()

    return render(request, 'notes1/note_create.html', {'form': form, 'category': category})



@login_required
def note_update(request, category_id, note_id):
    category = get_object_or_404(Category, id=category_id)
    note = get_object_or_404(Note, id=note_id)

    if request.method == 'POST':
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            #return redirect(note.get_absolute_url())
            return redirect('notes1:category_detail', category_id=category.id)
    else:
        form = NoteForm(instance=note)

    return render(request, 'notes1/note_update.html', {'form': form, 'category': category, 'note': note})


@login_required
def note_delete(request, category_id, note_id):
    note = get_object_or_404(Note, id=note_id)
    note.delete()
    return redirect('notes1:category_detail', category_id=category_id)

@login_required
def category_detail(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    user = request.user
    notes = Note.objects.filter(category=category,creator=user)

    return render(request, 'notes1/category_detail.html', {'category': category, 'notes': notes})

@login_required
def note_detail(request, category_id, note_id):
    note = get_object_or_404(Note, id=note_id)

    return render(request, 'notes1/note_detail.html', {'note': note})

def navigation(request, category_id):
    return render(request, 'notes1/navi.html', {'category_id': category_id})

def category_index(request):
    category_list = Category.objects.all()
    return render(request, "notes1/category_list.html", {"category_list": category_list})