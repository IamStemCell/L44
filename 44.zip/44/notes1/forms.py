from django import forms
from django.contrib.auth import authenticate
from django.utils import timezone
from .models import Category, Note

class NoteForm(forms.ModelForm):
    class Meta:
        model = Note
        fields = ['title', 'text', 'reminder', 'category', 'creator']

    def clean(self):
        cleaned_data = super().clean()
        reminder = cleaned_data.get('reminder')

        if reminder and reminder < timezone.now():
            raise forms.ValidationError("Reminder date must be in the future.")

        return cleaned_data


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['title']



class LoginForm(forms.Form):
    username = forms.CharField(max_length=100)
    password = forms.CharField(widget=forms.PasswordInput)

    def clean(self):
        cleaned_data = super().clean()
        username = cleaned_data.get('username')
        password = cleaned_data.get('password')

        if username and password:
            user = authenticate(username=username, password=password)
            if user is None:
                raise forms.ValidationError("Invalid username or password.")
        return cleaned_data