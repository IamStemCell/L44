from django.urls import path
from . import views
#from .views import NoteCreateView, NoteUpdateView, NoteDeleteView, NoteListView

app_name = 'notes1'
urlpatterns = [
    #path("", views.index, name = 'index'),
    path("", views.home, name = 'home'),
    #path('create/', NoteCreateView.as_view(), name='note_create'), these did work with old views
    #path('update/<int:note_id>/', NoteUpdateView.as_view(), name='note_update'),
   # path('delete/<int:note_id>/', NoteDeleteView.as_view(), name='note_delete'),
    #path('list/', NoteListView.as_view(), name='note_list'),
    path('1', views.category_index, name="category_index"),
    path('c/<int:category_id>/menu/', views.navigation, name='menu'),
    path('c/<int:category_id>/', views.category_detail, name='category_detail'),
    path('c/<int:category_id>/note/create/', views.note_create, name='note_create'),
    path('c/<int:category_id>/note/<int:note_id>/update/', views.note_update, name='note_update'),
    path('c/<int:category_id>/note/<int:note_id>/delete/', views.note_delete, name='note_delete'),
    path('c/<int:category_id>/note/<int:note_id>/', views.note_detail, name='note_detail'),
    path('2', views.creator_view, name="creator_view"),



]